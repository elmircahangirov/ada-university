#include <stdio.h>

int main(void) {
    int x;
    int guess;
    int count = 0;

    x = rand() % 30 - 11;   
    do {
        printf("Enter your guess: ");
        scanf("%d", &guess);
        count++;

        if (guess > x) {
            printf("Nope! Try smaller\n");
        } else if (guess < x) {
            printf("Nope! Try bigger\n");
        }
    } while (guess != x);

    printf("Now you got it!\n");
    printf("Total guesses you did to win: %d\n", count);

    return 0;
}