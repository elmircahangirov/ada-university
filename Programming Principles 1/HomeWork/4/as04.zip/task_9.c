#include <stdio.h>

int main(void) {
    int n, i, c, v;

    printf("Enter N (1 < N < 10): ");
    scanf("%d", &n);

    for (i = 1; i <= n; i++) {                 /* rows */
        for (c = 1; c <= 2 * n - 1; c++) {     /* columns */
            if (c <= n) {
                v = c;                         /* going up: 1 2 3 ... N */
            } else {
                v = 2 * n - c;                 /* going down: N-1 ... 1 */
            }

            if (v <= n - i + 1) {
                printf("%d  ", v);             /* print the number */
            } else {
                printf("   ");                 /* print blank space */
            }
        }
        printf("\n");
    }

    return 0;
}