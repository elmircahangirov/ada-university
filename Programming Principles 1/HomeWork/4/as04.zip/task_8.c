#include <stdio.h>

int main(void) {
    int n, i, j, d, count, mid;

    printf("Enter N (odd, N > 2): ");
    scanf("%d", &n);

    mid = n / 2;   /* index of the middle row (0-based) */

    for (i = 0; i < n; i++) {
        /* d = distance from the nearest top/bottom edge */
        if (i <= mid) {
            d = i;
        } else {
            d = n - 1 - i;
        }

        count = 2 * d + 1;   /* number of symbols on this row */

        /* leading spaces to center the row */
        for (j = 0; j < n - count; j++) {
            printf(" ");
        }

        /* symbols: '*' in the center (or everywhere on the middle row), '#' otherwise */
        for (j = 0; j < count; j++) {
            if (d == mid || j == d) {
                printf("* ");
            } else {
                printf("# ");
            }
        }
        printf("\n");
    }

    return 0;
}